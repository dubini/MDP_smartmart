package com.example.notipay_1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class mart_AccountActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mart_account);

        final mart_Server_chat server_chat;
        server_chat = new mart_Server_chat();
        server_chat.connser();

        final EditText accname_et = (EditText)findViewById(R.id.accname_et);
        final EditText accnum_et = (EditText)findViewById(R.id.accnum_et);
        final EditText pin_et = (EditText)findViewById(R.id.pin_et);

        Button finish = (Button)findViewById(R.id.finish);

        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String accname = String.valueOf(accname_et);
                String accunm = String.valueOf(accnum_et);
                String pin = String.valueOf(pin_et);

                String account = accname+","+accunm+","+pin;

                server_chat.senddata(account); //server_chat 의 함수 senddata 에 변수 bar_code를 넣어 실행
                String receive = String.valueOf(mart_Server_chat.receive);



            }
        });


    }
}
