package com.example.administrator.smartcart;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Shopping_ca extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_ca);

        Button bascan = (Button)findViewById(R.id.bascan);
        TextView test_1 = (TextView)findViewById(R.id.test_1);

        bascan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Shopping_ca.this,Bascan_ca.class);
                startActivity(intent);
            }
        });
        Intent intent_1 = getIntent();
        String data = intent_1.getStringExtra("value");
        test_1.setText(data);
    }

}
