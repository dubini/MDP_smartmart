package com.example.administrator.smartcart;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONObject;

public class Bascan_ca extends AppCompatActivity {

    private IntentIntegrator bascan;
    String data;
    public String temp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        bascan = new IntentIntegrator(this);
        bascan.setPrompt("");
        bascan.setOrientationLocked(false);
        bascan.initiateScan();

    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        JSONObject jsonObject = new JSONObject();

        if (result != null) {
            if (result.getContents() == null) {
                Log.v("qrcode :::::::::::", "no contents");
            } else { //QR코드, 내용 존재
                try {
                    /* QR 코드 내용*/
                    temp = result.getContents();
                    jsonObject.accumulate("temp",data);
                    Toast.makeText(getApplicationContext(), result.getContents(), Toast.LENGTH_LONG).show();



                } catch (Exception e) {
                    e.printStackTrace();
                    Log.v("Exception :::::::::::::", "QR code fail");
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
        sungsup();

    }
    public void sungsup (){
    Intent intent = new Intent(Bascan_ca.this, Shopping_ca.class);
    intent.putExtra("value",temp);
    startActivity(intent);
    finish();
    }

}
